-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- 主機： localhost
-- 產生時間： 2021 年 06 月 21 日 19:55
-- 伺服器版本： 10.4.19-MariaDB
-- PHP 版本： 7.3.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `lazybones`
--

-- --------------------------------------------------------

--
-- 資料表結構 `advi`
--

CREATE TABLE `advi` (
  `advise` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 傾印資料表的資料 `advi`
--

INSERT INTO `advi` (`advise`) VALUES
(''),
('hjhuhhibnmchjbjlhi'),
('s'),
('s'),
('s'),
('s'),
('s'),
('s'),
('hjhuhhibnmchjbjlhi'),
('MHsu 真是太棒拉！讓我過吧');

-- --------------------------------------------------------

--
-- 資料表結構 `information`
--

CREATE TABLE `information` (
  `count` varchar(100) NOT NULL,
  `cartype` varchar(100) NOT NULL,
  `carlevel` varchar(100) NOT NULL,
  `driversex` varchar(100) NOT NULL,
  `driverpmy` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 傾印資料表的資料 `information`
--

INSERT INTO `information` (`count`, `cartype`, `carlevel`, `driversex`, `driverpmy`, `address`) VALUES
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('', '', '', '', '', ''),
('四人', '大', 'Boss', 'women', '', ''),
('四人', '大', 'Boss', 'women', '', ''),
('四人', '大', 'Boss', 'women', 'in', 'mmmm'),
('四人', '大', 'Boss', 'women', 'in', 'sss'),
('四人', '大', 'Boss', 'women', 'in', 'aaaa'),
('四人', '大', 'Boss', 'women', 'in', '11111'),
('四人', '大', 'Boss', 'women', 'in', '新北市新店區安祥路106巷'),
('四人', '大', 'Boss', 'women', '穩重少言', 'dddddd'),
('四人', '大', 'Boss', '女生', '穩重少言', 'ffff'),
('二人', '中', 'normal', '男生', '穩重少言', '伴吾別墅'),
('二人', '大', 'Premium', '男生', '穩重少言', '伴吾別墅'),
('四人', '大', 'Boss', '女生', '穩重少言', '南京復興'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', '2222'),
('四人', '大', 'Boss', '女生', '穩重少言', 'non'),
('四人', '大', 'Boss', '女生', '穩重少言', 'non'),
('四人', '大', 'Boss', '女生', '穩重少言', 'non'),
('四人', '大', 'Boss', '女生', '穩重少言', 'non'),
('四人', '大', 'Boss', '女生', '穩重少言', 'non'),
('四人', '大', 'Boss', '女生', '穩重少言', 'efefefefefefe'),
('四人', '大', 'Boss', '女生', '穩重少言', ''),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('四人', '大', 'Boss', '女生', '穩重少言', 'vhf'),
('一人', '中', 'Premium', '女生', '穩重少言', '東吳大學'),
('二人', '大', 'Boss', '女生', '開朗活潑', '你心裡');

-- --------------------------------------------------------

--
-- 替換檢視表以便查看 `lazybones`
-- (請參考以下實際畫面)
--
CREATE TABLE `lazybones` (
);

-- --------------------------------------------------------

--
-- 資料表結構 `login`
--

CREATE TABLE `login` (
  `name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 傾印資料表的資料 `login`
--

INSERT INTO `login` (`name`, `password`) VALUES
('1111', '1111'),
('David', '20020210'),
('dddd', 'dddd'),
('ffff', 'ffff'),
('David', '20020210'),
('Peter', 'peter'),
('ssss', 'ssss'),
('1202', '2222'),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('', ''),
('max', ''),
('', ''),
('', ''),
('David', '20020210'),
('MHsu', 'handsomeboy');

-- --------------------------------------------------------

--
-- 檢視表結構 `lazybones`
--
DROP TABLE IF EXISTS `lazybones`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `lazybones`  AS SELECT `login`.`id` AS `id`, `login`.`name` AS `name`, `login`.`password` AS `password` FROM `login` ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
